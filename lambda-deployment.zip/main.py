from btry.api import RapidAPI
from loguru import logger
from dynamodbhandler import DynamoDBHandler  # Use the new handler

def lambda_handler(event, context):
    # Initialize RapidAPI
    rapid_api = RapidAPI()

    # Initialize DynamoDB Handler
    dynamo_handler = DynamoDBHandler(table_name="FantasyPlayersData")

    try:
        # Fetch team data (dummy example)
        logger.info("Fetching team data...")
        teams = [{"team": {"id": 1, "name": "Team A"}}, {"team": {"id": 2, "name": "Team B"}}]

        for team in teams:
            logger.info(f"Processing players for team: {team['team']['name']}")
            players = rapid_api.get_team_players(team_id=team["team"]["id"])

            # Insert players into DynamoDB
            for player in players:
                dynamo_handler.insert_document({
                    "PlayerID": player["id"],
                    "Name": player["name"],
                    "Team": team["team"]["name"],
                    "Stats": player["stats"]
                })

    except Exception as e:
        logger.error(f"An error occurred: {e}")
        raise

    return {"statusCode": 200, "body": "Data processing completed successfully."}
